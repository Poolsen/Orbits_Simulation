This projects simulates the orbits of at least two objects using python.
